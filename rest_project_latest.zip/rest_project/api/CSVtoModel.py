from api.models import GameHistoryModel
import csv

csvPath = 'api/vgsales.csv'

with open(csvPath, newline='') as csvFile:
    csvread = csv.reader(csvFile)

    for row in csvread:
        try:
            GameHistoryModel.objects.create(Rank=row[0], Name=row[1], Platform=row[2], Year=row[3], Genre=row[4],
                                            Publisher=row[5],
                                            NA_Sales=row[6], EU_Sales=row[7], JP_Sales=row[8], Other_Sales=row[9],
                                            Global_Sales=row[10])
        except:
            continue
