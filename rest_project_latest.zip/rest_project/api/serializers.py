from rest_framework import serializers
from .models import GameHistoryModel


class GameSerializer(serializers.ModelSerializer):
    class Meta:
        model = GameHistoryModel
        fields = '__all__'


class GameSaleSerializer(serializers.ModelSerializer):
    class Meta:
        model = GameHistoryModel
        fields = ['NA_Sales', 'JP_Sales', 'EU_Sales', 'Other_Sales', 'Global_Sales', ]

