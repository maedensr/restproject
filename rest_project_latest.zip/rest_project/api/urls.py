from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from .views import GameDetailView, GameListNameView, GameListYearView, GameListCategoryView, GameListPlatformView, \
    GameListPlatformYearView, CompareGamesSalesView, CompareTotalSaleView, ComparePublishersTotalSaleView, CompareGenresTotalSaleView
from rest_framework_simplejwt import views as jwt_views

urlpatterns = [
    path('ranks/<int:rank>/games/', GameDetailView.as_view()),
    path('games/<str:name>/', GameListNameView.as_view()),
    path('platforms/<str:platform>/top/<int:N>/games/', GameListPlatformView.as_view()),
    path('years/<int:year>/top/<int:N>/games/', GameListYearView.as_view()),
    path('genres/<str:genre>/top/<int:N>/games/', GameListCategoryView.as_view()),
    path('platforms/<str:platform>/year/<int:year>/games/', GameListPlatformYearView.as_view()),
    path('chart/ranks/<int:first_rank>/<int:second_rank>/sales/', CompareGamesSalesView.as_view()),
    path('chart/years/<int:start_year>/<int:end_year>/sales/', CompareTotalSaleView.as_view()),
    path('chart/years/<int:start_year>/<int:end_year>/publishers/<str:first_publisher>/<str:second_publisher>/sales/', ComparePublishersTotalSaleView.as_view()),
    path('chart/years/<int:start_year>/<int:end_year>/genres/sales/', CompareGenresTotalSaleView.as_view()),
    path('token/', jwt_views.TokenObtainPairView.as_view()),
    path('token/refresh/', jwt_views.TokenRefreshView.as_view()),
]
