from django.db import models

# Create your models here.


class GameHistoryModel(models.Model):
    Rank = models.DecimalField(max_digits=6, decimal_places=0)
    Name = models.CharField(max_length=60)
    Platform = models.CharField(max_length=50)
    Year = models.DecimalField(max_digits=4, decimal_places=0)
    Genre = models.CharField(max_length=50)
    Publisher = models.CharField(max_length=60)
    NA_Sales = models.DecimalField(max_digits=6, decimal_places=2)
    EU_Sales = models.DecimalField(max_digits=6, decimal_places=2)
    JP_Sales = models.DecimalField(max_digits=6, decimal_places=2)
    Other_Sales = models.DecimalField(max_digits=6, decimal_places=2)
    Global_Sales = models.DecimalField(max_digits=6, decimal_places=2)

    class Meta:
        app_label = 'api'

    def __str__(self):
        return self.Name