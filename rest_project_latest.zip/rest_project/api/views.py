from rest_framework import generics, permissions, views
from rest_framework.response import Response
from .serializers import GameSerializer, GameSaleSerializer
from .models import GameHistoryModel
from django.shortcuts import get_object_or_404
from django.db.models import F


# Create your views here.

class GameDetailView(generics.RetrieveAPIView):
    serializer_class = GameSerializer

    def get_object(self):
        rank = self.kwargs['rank']
        return get_object_or_404(GameHistoryModel, Rank=rank)


class GameListNameView(generics.ListAPIView):
    serializer_class = GameSerializer

    def get_queryset(self):
        name = self.kwargs['name']
        return GameHistoryModel.objects.filter(Name__icontains=name)


class GameListPlatformView(generics.ListAPIView):
    serializer_class = GameSerializer

    def get_queryset(self):
        N = self.kwargs['N']
        platform = self.kwargs['platform']
        return GameHistoryModel.objects.filter(Platform=platform).order_by('-Rank')[:int(N)]


class GameListYearView(generics.ListAPIView):
    serializer_class = GameSerializer

    def get_queryset(self):
        N = self.kwargs['N']
        year = self.kwargs['year']
        return GameHistoryModel.objects.filter(Year=year).order_by('-Rank')[:int(N)]


class GameListCategoryView(generics.ListAPIView):
    serializer_class = GameSerializer

    def get_queryset(self):
        N = self.kwargs['N']
        category = self.kwargs['genre']
        return GameHistoryModel.objects.filter(Genre=category).order_by('-Rank')[:int(N)]


class GameListPlatformYearView(generics.ListAPIView):
    serializer_class = GameSerializer

    def get_queryset(self):
        platform = self.kwargs['platform']
        year = self.kwargs['year']
        qs = GameHistoryModel.objects.filter(Platform=platform)
        return qs.filter(Year=year).order_by('Global_Sales')[:5]


class MostSaleView(generics.ListAPIView):
    serializer_class = GameSerializer

    def get_queryset(self):
        return GameHistoryModel.objects.filter(EU_Sales__gt=F('NA_Sales'))


class CompareGamesSalesView(views.APIView):
    serializer_class = GameSaleSerializer

    def get(self, request, format=None, **kwargs):
        first_game = get_object_or_404(GameHistoryModel, Rank=self.kwargs['first_rank'])
        second_game = get_object_or_404(GameHistoryModel, Rank=self.kwargs['second_rank'])
        data = {'games': [first_game.Name, second_game.Name],
                'global': [first_game.Global_Sales, second_game.Global_Sales],
                'other': [first_game.Other_Sales, second_game.Other_Sales],
                'na': [first_game.NA_Sales, second_game.NA_Sales],
                'eu': [first_game.EU_Sales, second_game.EU_Sales],
                'jp': [first_game.JP_Sales, second_game.JP_Sales]}
        return Response(data)


class CompareTotalSaleView(views.APIView):

    def get(self, request, format=None, **kwargs):
        data = {'years': [], 'total_sale': []}
        start = kwargs['start_year']
        end = kwargs['end_year']
        for year in range(start, end + 1):
            objects = GameHistoryModel.objects.filter(Year=year)
            total_sale = 0
            for object in objects:
                total_sale = total_sale + object.Global_Sales

            data['years'].append(year)
            data['total_sale'].append(total_sale)

        return Response(data)


class ComparePublishersTotalSaleView(views.APIView):
    def get(self, request, format=None, **kwargs):
        data = {
            'years': [],
            'first_publisher': [],
            'second_publisher': []
        }
        start = kwargs['start_year']
        end = kwargs['end_year']
        for year in range(start, end + 1):
            objects = GameHistoryModel.objects.filter(Year=year)

            first_publisher = kwargs['first_publisher']
            second_publisher = kwargs['second_publisher']

            first_publisher_games = objects.filter(Publisher=first_publisher)
            second_publisher_games = objects.filter(Publisher=second_publisher)

            first_publisher_sale = 0
            second_publisher_sale = 0
            for object in first_publisher_games:
                first_publisher_sale = first_publisher_sale + object.Global_Sales
            for object in second_publisher_games:
                second_publisher_sale = first_publisher_sale + object.Global_Sales

            data['years'].append(year)
            data['first_publisher'].append(first_publisher_sale)
            data['second_publisher'].append(second_publisher_sale)

        return Response(data)


class CompareGenresTotalSaleView(views.APIView):
    def get(self, request, format=None, **kwargs):
        genres = ['Strategy', 'Adventure', 'Simulation', 'Role-Playing', 'Racing', 'Platform', 'Misc', 'Fighting',
                  'Action', 'Shooter', 'Puzzle', 'Sports']
        data = {
            'genres': genres,
            'total_sales': []
        }
        start = kwargs['start_year']
        end = kwargs['end_year']
        for genre in genres:
            objects = GameHistoryModel.objects.filter(Genre=genre)
            sale = 0
            for year in range(start, end + 1):
                genre_games = objects.filter(Year=year)

                for game in genre_games:
                    sale = sale + game.Global_Sales

            data['total_sales'].append(sale)

        return Response(data)
