from django.shortcuts import render
from django.views import View


# Create your views here.

class YearSalePageView(View):
    def get(self, request, *args, **kwargs):
        context = {
            'start_year': kwargs['start_year'],
            'end_year': kwargs['end_year'],
        }
        return render(request, 'charts2.html', context)

class GameSalePageView(View):

    def get(self, request, *args, **kwargs):
        context = {
            'first_rank': kwargs['first_rank'],
            'second_rank': kwargs['second_rank'],
        }
        return render(request, 'charts.html', context)


class PublishersSalePageView(View):
    def get(self, request, *args, **kwargs):
        context = {
            'start_year': kwargs['start_year'],
            'end_year': kwargs['end_year'],
            'first_publisher': kwargs['first_publisher'],
            'second_publisher': kwargs['second_publisher'],
        }
        return render(request, 'charts3.html', context)


class GenresSalePageView(View):
    def get(self, request, *args, **kwargs):
        context = {
            'start_year': kwargs['start_year'],
            'end_year': kwargs['end_year'],
        }
        return render(request, 'charts4.html', context)
