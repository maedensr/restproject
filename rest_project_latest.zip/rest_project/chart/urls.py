from django.contrib import admin
from django.urls import path, include
from .views import YearSalePageView, GameSalePageView, PublishersSalePageView, GenresSalePageView

urlpatterns = [
    path('years/<int:start_year>/<int:end_year>/', YearSalePageView.as_view()),
    path('ranks/<int:first_rank>/<int:second_rank>/', GameSalePageView.as_view()),
    path('years/<int:start_year>/<int:end_year>/publishers/<str:first_publisher>/<str:second_publisher>/', PublishersSalePageView.as_view()),
    path('years/<int:start_year>/<int:end_year>/genres/', GenresSalePageView.as_view()),
]